package com.freedom.freedom_backend.asset;

import com.freedom.freedom_backend.user.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class SystemCashService {

    private final JdbcTemplate jdbc;

    public SystemCashService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void ensureExists(User user) {
        Integer count = jdbc.queryForObject(
                """
                SELECT COUNT(*)
                FROM assets
                WHERE user_id = ?
                  AND system_cash = TRUE
                """,
                Integer.class,
                user.getId()
        );

        if (count != null && count > 0) {
            return;
        }

        jdbc.update(
                """
                INSERT INTO assets (
                    user_id,
                    name,
                    value,
                    color,
                    category,
                    icon_key,
                    system_cash
                )
                VALUES (?, 'Gotówka', 0.00, '#3b82f6', 'CASH', 'wallet', TRUE)
                """,
                user.getId()
        );
    }

    public void applyDelta(User user, BigDecimal delta) {
        ensureExists(user);

        jdbc.update(
                """
                UPDATE assets
                SET value = value + ?
                WHERE user_id = ?
                  AND system_cash = TRUE
                """,
                delta,
                user.getId()
        );
    }
}
